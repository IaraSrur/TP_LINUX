#! /bin/bash

esLaborable() {

fecha=$1
diaSemana=$(date -d "$fecha" +"%u")    #Verifica si es fin de semana      
if [ $diaSemana -eq 6 ] || [ $diaSemana -eq 7 ]; then
	echo "La fecha $fecha es fin de semana"
	return 1
fi
#Lista de feriados:
feriados=("2023-01-01" "2023-03-24" "2023-04-02" "2023-05-01" "2023-05-25" "2023-06-01" "2023-07-09" "2023-08-17" "2023-10-12" "2023-11-20" "2023-12-08" "2023-12-25")
#Compara la lista y verifica si es un dia feriado: 
for feriado in "${feriados[@]}"; do
	if [ "$feriado" == "$fecha" ]; then
		echo "La fecha $fecha es un dia feriado."
		return 1
	fi
done 
#Si no es un dia feriado ni fin de semana, es dia laborable: 
echo "La fecha $fecha es un dia laborable."
return 0
 

} 
 
