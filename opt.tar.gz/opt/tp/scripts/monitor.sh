#! /bin/bash
#Verifica si ingresa un proceso:
if [ -z "$1" ]; then
	echo "Error, proporcione el nombre de un proceso como argumento"
	exit 1
fi
#Obtiene el nombre del proceso desde el argumento:
process_name="$1"

#Verifica si el proceso esta en ejecucion, si lo esta entonces muestra:
if pgrep "$process_name" > /dev/null; then
	echo "El proceso '$process_name' esta en ejecucion"
else  #Si no lo está, entonces envia mail a root: 
	echo "El proceso '$process_name' no esta en ejecucion. Enviando correo a root"
	echo "El proceso '$process_name' no esta en ejecucion en $(hostname)" | mail -s "Proceso no encontrado" root
fi
