#! /bin/bash

#Fecha:
function log() {
	timestamp=$(date +"%H:%M:%S")
	echo "$timestamp - $1" >> backup.log
}
#Le envia a root el log por mail:
function enviar_log_por_correo() {
	cat backup.log | mail -s "Registro de backup" root
 
}
#Si se cumplen las verificaciones y las condiciones, realiza el backup:
function realizar_backup() {
	source_dir=$1
	dest_dir=$2
#Verifica si existen los directorios de origen y destino:	
if [ ! -d "$source_dir" ]; then
	log "Error: El directorio de origen $source_dir no existe"
	exit 1
fi

if [ ! -d "$dest_dir" ]; then
	log "Error: El directorio de destino $dest_dir no existe."
	exit 1
fi
#Realiza el backup, comprime en .tar.gz y lo nombra con fecha de formato ANSI:
	base_dir=$(basename "$source_dir")

	backup_file="$base_dir\_bkp_$(date +"%Y%m%d").tar.gz"

	log "Realizando backup de $source_dir a $dest_dir/$backup_file"

	tar -czf "$dest_dir/$backup_file" "$source_dir" 
	
	log "Backup completado."
}

#Ayuda (-h):
while getopts "h" opt; do
	case $opt in
	h)
	echo "Uso: backup_full.sh [-h] directorio_origen directorio_destino"
	echo " -h: Mostrar esta ayuda."
	exit 0 
	;;
	esac
done

shift $((OPTIND -1))

if [ $# -ne 2 ]; then
	echo "Error: Se deben proporcionar los directorios de origen y destino"
	echo "Uso: backup_full.sh [-h] directorio_origen directorio_destino"
	exit 1
fi

origen=$1
destino=$2

dia_semana=$(date +"%u")
hora=$(date +"%H")

log "Inicio del script de backup."

if [ $dia_semana -eq 7 ] && [ $hora -eq 23 ]; then

	realizar_backup "/u01" "/u03"
	realizar_backup "/u02" "/u03"
else
	realizar_backup "/etc" "/u03"
	realizar_backup "/var/log" "/u03"

fi

log "Fin del script de backup"
enviar_log_por_correo
