#! /bin/bash

source esLaborable.sh
#Feriados nacionales: 
fecha1="2023-01-01"
esLaborable "$fecha1"

fecha2="2023-03-24"
esLaborable "$fecha2"

fecha3="2023-04-02"
esLaborable "$fecha3"

fecha4="2023-05-01"
esLaborable "$fecha4"

fecha5="2023-05-25"
esLaborable "$fecha5"

fecha6="2023-06-20"
esLaborable "$fecha6"

fecha7="2023-07-09"
esLaborable "$fecha7"

fecha8="2023-08-17"
esLaborable "$fecha8"

fecha9="2023-10-12"
esLaborable "$fecha9"

fecha10="2023-11-20"
esLaborable "$fecha10"

fecha11="2023-12-08"
esLaborable "$fecha11"

fecha12="2023-12-25"
esLaborable "$fecha12" 

 
